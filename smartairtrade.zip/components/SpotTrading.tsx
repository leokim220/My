import React, { useState, useEffect } from 'react';
import OrderForm from './OrderForm';
import TradeHistory from './TradeHistory';
import useMockMarketData from '../hooks/useMockMarketData';
import type { CryptoPair } from '../types';
import { useMarketData } from '../contexts/MarketDataContext';
import { usePriceChange } from '../hooks/usePriceChange';


const TradePage: React.FC = () => {
  const { pairs } = useMarketData();
  const [selectedPair, setSelectedPair] = useState<CryptoPair>(pairs[0]);
  const { tradeHistory } = useMockMarketData(selectedPair);

  useEffect(() => {
    // Keep selected pair data in sync with the live market data from context
    const currentPair = pairs.find(p => p.id === selectedPair.id);
    if (currentPair) {
      setSelectedPair(currentPair);
    } else if (pairs.length > 0) {
      // Handle case where pair is no longer available, fall back to first pair
      setSelectedPair(pairs[0]);
    }
  }, [pairs, selectedPair.id]);

  // A helper to get a plausible symbol from the name
  const getSymbol = (name: string) => {
    const symbols: {[key: string]: string} = {
        'Bitcoin': 'BTC', 'Ethereum': 'ETH', 'Solana': 'SOL', 'BNB': 'BNB',
        'XRP': 'XRP', 'Dogecoin': 'DOGE', 'Cardano': 'ADA', 'Avalanche': 'AVAX',
        'Chainlink': 'LINK', 'Polkadot': 'DOT',
    };
    return symbols[name] || name.substring(0,3).toUpperCase();
  }

  const MarketHeader = () => {
    const priceStatus = usePriceChange(selectedPair.price);
    const flashClass = {
        up: 'flash-green',
        down: 'flash-red',
        neutral: ''
    }[priceStatus];
    
    return (
    <div className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm rounded-md p-3 flex flex-wrap items-center justify-between gap-y-4">
      <div className="flex items-center space-x-3">
        <img src={`https://picsum.photos/seed/${selectedPair.base}/40`} alt={selectedPair.base} className="w-8 h-8 sm:w-10 sm:h-10 rounded-full" />
        <div>
          <h1 className="text-lg sm:text-2xl font-bold text-slate-900 dark:text-white">{getSymbol(selectedPair.base)}/{selectedPair.quote}</h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">{selectedPair.base}</p>
        </div>
      </div>
      
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-2 text-right w-full sm:w-auto text-xs sm:text-sm order-3 sm:order-2">
        <div className={`p-1 rounded transition-colors ${flashClass}`}>
          <p className="text-slate-500 dark:text-slate-400">Last Price</p>
          <p className={`font-mono sm:text-base ${selectedPair.change24h >= 0 ? 'text-green-500 dark:text-green-400' : 'text-red-500 dark:text-red-400'}`}>{selectedPair.price.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
        </div>
        <div>
          <p className="text-slate-500 dark:text-slate-400">24h Change</p>
          <p className={`font-mono sm:text-base ${selectedPair.change24h >= 0 ? 'text-green-500 dark:text-green-400' : 'text-red-500 dark:text-red-400'}`}>{selectedPair.change24h.toFixed(2)}%</p>
        </div>
        <div>
          <p className="text-slate-500 dark:text-slate-400">24h High</p>
          <p className="font-mono text-slate-900 dark:text-white sm:text-base">{(selectedPair.price * 1.035).toLocaleString(undefined, {minimumFractionDigits: 2})}</p>
        </div>
        <div>
          <p className="text-slate-500 dark:text-slate-400">24h Low</p>
          <p className="font-mono text-slate-900 dark:text-white sm:text-base">{(selectedPair.price * 0.972).toLocaleString(undefined, {minimumFractionDigits: 2})}</p>
        </div>
      </div>

       <div className="relative w-full sm:w-60 order-2 sm:order-3">
          <select
            value={selectedPair.id}
            onChange={(e) => {
              const newPair = pairs.find(p => p.id === e.target.value);
              if (newPair) setSelectedPair(newPair);
            }}
            className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-md py-2 pl-3 pr-8 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-500 appearance-none"
            aria-label="Select cryptocurrency pair"
          >
            {pairs.map(p => <option key={p.id} value={p.id}>{getSymbol(p.base)}/{p.quote}</option>)}
          </select>
          <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
            <svg className="w-4 h-4 fill-current text-slate-400" viewBox="0 0 20 20"><path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" fillRule="evenodd"></path></svg>
          </div>
      </div>
    </div>
  )};

  return (
    <div className="flex flex-col gap-4">
      <MarketHeader />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm rounded-md">
            <OrderForm />
        </div>
        <div className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm rounded-md h-[480px] flex flex-col">
            <TradeHistory trades={tradeHistory} />
        </div>
      </div>
    </div>
  );
};

export default TradePage;