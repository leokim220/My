import React from 'react';
import { ArrowLeftIcon, HomeIcon, CoinStackIcon, CreditCardIcon } from './icons';

const MiningRulesPage: React.FC<{
  onBack: () => void;
  onNavigate: (view: 'mining' | 'dashboard') => void;
}> = ({ onBack, onNavigate }) => {
  return (
    <div className="max-w-xl mx-auto text-white dark font-sans antialiased relative pb-24">
      {/* Background elements */}
      <div className="absolute inset-0 z-[-1] overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-slate-900"></div>
        <div 
          className="absolute bottom-0 left-0 w-full h-1/2 opacity-20"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Cg fill-rule='evenodd'%3E%3Cg fill='%2322d3ee' fill-opacity='0.1'%3E%3Cpath opacity='.5' d='M96 95h4v1h-4v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9zm-1 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm9-10v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm9-10v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm9-10v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            backgroundRepeat: 'repeat',
          }}
        ></div>
      </div>
      
      <header className="flex items-center justify-between p-4 sticky top-0 bg-slate-900/50 backdrop-blur-sm z-10">
        <button onClick={onBack} className="p-2 -ml-2 rounded-full text-slate-300 hover:text-white">
          <ArrowLeftIcon className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-bold">Rules</h1>
        <button onClick={() => onNavigate('dashboard')} className="p-2 -mr-2 rounded-full text-slate-300 hover:text-white">
          <HomeIcon className="w-6 h-6" />
        </button>
      </header>
      
      <main className="p-6 space-y-10">
        <section>
          <h2 className="text-center font-bold text-lg text-cyan-400 mb-2">Non Stop Profits</h2>
          <p className="text-sm text-slate-400 leading-relaxed text-center">
            Brick-moving is through the transfer of USDT to the platform, and the professional team of the platform carries out the arbitrage of the brick-moving. Participants can obtain the platform's brick-moving income during the period of capital deployment.
          </p>
        </section>

        <section className="bg-slate-800/60 rounded-xl p-6 border border-slate-700 shadow-lg">
          <h3 className="text-center font-bold text-lg text-cyan-400 mb-6">Product Highlights</h3>
          <div className="flex justify-around items-start mb-6 text-center">
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center mb-2 shadow-[0_0_15px_rgba(34,211,238,0.5)]">
                <CoinStackIcon className="w-8 h-8 text-white" />
              </div>
              <p className="font-bold text-sm">Save as you go</p>
              <p className="text-xs text-slate-400">Dividend Payout Period</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-pink-500 to-purple-500 flex items-center justify-center mb-2 shadow-[0_0_15px_rgba(236,72,153,0.5)]">
                <CreditCardIcon className="w-8 h-8 text-white" />
              </div>
              <p className="font-bold text-sm">Post daily</p>
              <p className="text-xs text-slate-400">Current Interest</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-center text-xs">
            <div className="border border-slate-600 rounded-full px-3 py-2 text-slate-300">Unlimited income</div>
            <div className="border border-slate-600 rounded-full px-3 py-2 text-slate-300">100% Security guarantee</div>
            <div className="border border-slate-600 rounded-full px-3 py-2 text-slate-300 leading-tight">Interest will start on the next day of successful deposit</div>
          </div>
        </section>

        <section>
          <div className="flex items-center justify-center mb-4">
            <div className="flex-grow h-px bg-gradient-to-l from-cyan-400 to-transparent"></div>
            <h2 className="mx-4 text-center font-bold text-lg text-cyan-400 flex-shrink-0">Profit Calculations</h2>
            <div className="flex-grow h-px bg-gradient-to-r from-cyan-400 to-transparent"></div>
          </div>
          <p className="text-sm text-slate-400 leading-relaxed">
            After deposit and transfer USDT to the platform funding accounts, the daily income will be calculated. If the member deposits 10,000 USDT on the platform and chooses the 10-day period, and the daily income is 1.5% of the wealth management product, then daily income is as follows: 10000 USDT *1.5% = 150 USDT. That is: You can get 1500 USDT income after 10 days, and the income will be issued daily, and the principal will be refunded as well. After the expiration date, it will be automatically returned to you.
          </p>
        </section>
      </main>

      <footer className="fixed bottom-0 left-0 right-0 p-4 bg-slate-900/50 backdrop-blur-sm border-t border-slate-800">
        <div className="max-w-xl mx-auto">
            <button
                onClick={() => onNavigate('mining')}
                className="w-full text-center py-4 rounded-xl text-lg font-bold text-white bg-gradient-to-b from-teal-400 to-cyan-500 hover:from-teal-500 hover:to-cyan-600 shadow-lg shadow-cyan-500/20 transition-all duration-300"
            >
                Buy
            </button>
        </div>
      </footer>
    </div>
  );
};

export default MiningRulesPage;