import React, { useState, useMemo } from 'react';
import { LineChart, Line, ResponsiveContainer } from 'recharts';
import type { CryptoPair } from '../types';
import { MarketIcon } from './icons';
import { useMarketData } from '../contexts/MarketDataContext';

// A small, reusable sparkline chart component
const Sparkline: React.FC<{ data: number[]; isUp: boolean }> = ({ data, isUp }) => {
  const chartData = data.map(value => ({ value }));
  const color = isUp ? '#10b981' : '#ef4444'; // green-500 or red-500
  return (
    <div className="w-24 h-10">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData}>
          <Line type="monotone" dataKey="value" stroke={color} strokeWidth={2} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

// Helper for formatting large numbers
const formatMarketData = (num: number): string => {
  if (num >= 1_000_000_000_000) {
    return `$${(num / 1_000_000_000_000).toFixed(2)}T`;
  }
  if (num >= 1_000_000_000) {
    return `$${(num / 1_000_000_000).toFixed(2)}B`;
  }
  if (num >= 1_000_000) {
    return `$${(num / 1_000_000).toFixed(2)}M`;
  }
  return `$${num.toLocaleString()}`;
};

type SortKey = 'base' | 'change7d' | 'change24h' | 'marketCap' | 'volume24h';

interface MarketPageProps {
  onNavigate: (view: 'options', context: { pair: CryptoPair }) => void;
}

const MarketPage: React.FC<MarketPageProps> = ({ onNavigate }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortConfig, setSortConfig] = useState<{ key: SortKey; direction: 'ascending' | 'descending' } | null>({ key: 'marketCap', direction: 'descending' });
  const { pairs } = useMarketData();

  const sortedAndFilteredPairs = useMemo(() => {
    let filteredPairs = pairs.filter(pair =>
      pair.base.toLowerCase().includes(searchTerm.toLowerCase()) ||
      pair.id.split('-')[0].toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (sortConfig !== null) {
      filteredPairs.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'ascending' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'ascending' ? 1 : -1;
        }
        return 0;
      });
    }
    return filteredPairs;
  }, [searchTerm, sortConfig, pairs]);

  const requestSort = (key: SortKey) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };
  
  const getSortIcon = (key: SortKey) => {
    if (!sortConfig || sortConfig.key !== key) return null;
    return sortConfig.direction === 'ascending' ? '▲' : '▼';
  };

  const TableHeader: React.FC<{ sortKey: SortKey; label: string; className?: string }> = ({ sortKey, label, className }) => (
    <th className={`px-4 py-3 text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider ${className}`}>
      <button onClick={() => requestSort(sortKey)} className="flex items-center space-x-1 hover:text-slate-800 dark:hover:text-slate-200">
        <span>{label}</span>
        <span className="text-sky-500">{getSortIcon(sortKey)}</span>
      </button>
    </th>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center space-x-3">
            <MarketIcon className="w-8 h-8 text-sky-500 dark:text-sky-400" />
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Markets</h1>
        </div>
        <div className="w-full sm:w-64">
          <input
            type="text"
            placeholder="Search crypto..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-md py-2 px-4 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-500"
          />
        </div>
      </div>

      <div className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm rounded-xl shadow-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
            <thead className="bg-slate-50 dark:bg-slate-700/50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">#</th>
                <TableHeader sortKey="base" label="Name" className="text-left"/>
                <TableHeader sortKey="change7d" label="7d %" className="text-right"/>
                <TableHeader sortKey="change24h" label="24h %" className="text-right"/>
                <TableHeader sortKey="marketCap" label="Market Cap" className="text-right hidden sm:table-cell"/>
                <TableHeader sortKey="volume24h" label="Volume(24h)" className="text-right hidden md:table-cell"/>
                <th className="px-4 py-3 text-right text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider hidden lg:table-cell">Last 7 Days</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
              {sortedAndFilteredPairs.map((pair, index) => (
                <tr 
                  key={pair.id} 
                  className="hover:bg-slate-100/50 dark:hover:bg-slate-700/50 transition-colors cursor-pointer"
                  onClick={() => onNavigate('options', { pair })}
                >
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{index + 1}</td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <div className="flex items-center space-x-3">
                       <img src={`https://picsum.photos/seed/${pair.base}/32`} alt={pair.base} className="w-6 h-6 rounded-full" />
                       <div>
                         <p className="font-semibold text-slate-900 dark:text-white text-sm">{pair.base}</p>
                         <p className="text-xs text-slate-500 dark:text-slate-400">{pair.id.split('-')[0].toUpperCase()}</p>
                       </div>
                    </div>
                  </td>
                  <td className={`px-4 py-3 whitespace-nowrap text-right font-mono text-sm ${pair.change7d >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {pair.change7d.toFixed(2)}%
                  </td>
                  <td className={`px-4 py-3 whitespace-nowrap text-right font-mono text-sm ${pair.change24h >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {pair.change24h.toFixed(2)}%
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-right font-mono text-sm text-slate-500 dark:text-slate-400 hidden sm:table-cell">{formatMarketData(pair.marketCap)}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-right font-mono text-sm text-slate-500 dark:text-slate-400 hidden md:table-cell">{formatMarketData(pair.volume24h)}</td>
                  <td className="px-4 py-3 whitespace-nowrap hidden lg:table-cell">
                    <Sparkline data={pair.sparklineData} isUp={pair.change24h >= 0} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default MarketPage;