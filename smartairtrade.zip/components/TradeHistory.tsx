import React from 'react';
import type { Trade } from '../types';

interface TradeHistoryProps {
  trades: Trade[];
}

const TradeHistory: React.FC<TradeHistoryProps> = ({ trades }) => {
  return (
    <div className="flex flex-col h-full">
      <h2 className="text-base font-semibold text-slate-900 dark:text-white p-3 border-b border-slate-200 dark:border-slate-700">Market Trades</h2>
      <div className="grid grid-cols-3 gap-2 text-xs text-slate-500 dark:text-slate-400 px-3 py-2">
        <span>Price (USDT)</span>
        <span className="text-right">Amount (BTC)</span>
        <span className="text-right">Time</span>
      </div>
      <div className="flex-grow overflow-y-auto">
        {trades.map((trade) => (
          <div key={trade.id} className="grid grid-cols-3 gap-2 px-3 py-1 font-mono text-xs hover:bg-slate-100 dark:hover:bg-slate-700/50">
            <span className={trade.type === 'buy' ? 'text-green-500 dark:text-green-400' : 'text-red-500 dark:text-red-400'}>
              {trade.price.toFixed(2)}
            </span>
            <span className="text-right text-slate-800 dark:text-white">{trade.amount.toFixed(4)}</span>
            <span className="text-right text-slate-500 dark:text-slate-400">{trade.time}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TradeHistory;