import React from 'react';
import { ConstructionIcon } from './icons';

const FuturesTrading: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center h-[calc(100vh-200px)] bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm rounded-xl text-center p-8 border-2 border-dashed border-slate-300 dark:border-slate-700">
      <ConstructionIcon className="w-20 h-20 sm:w-24 sm:h-24 text-sky-500 mb-6" />
      <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 dark:text-white mb-2">Futures Trading</h1>
      <p className="text-lg sm:text-xl text-slate-500 dark:text-slate-400 max-w-md">
        This feature is currently under construction. Get ready for advanced trading tools, leverage, and perpetual contracts. Coming soon!
      </p>
    </div>
  );
};

export default FuturesTrading;