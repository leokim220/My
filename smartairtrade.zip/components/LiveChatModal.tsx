import React, { useState, useEffect, useRef } from 'react';
import { CloseIcon, SendIcon } from './icons';

interface LiveChatModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const LiveChatModal: React.FC<LiveChatModalProps> = ({ isOpen, onClose }) => {
    const [messages, setMessages] = useState([
        { id: 1, from: 'agent', text: 'Hello! Welcome to SmartAirTrade support. How can I help you today?' },
        { 
            id: 2, 
            from: 'agent', 
            text: <>You can also contact us via Telegram: <a href="https://t.me/XdyLn25" target="_blank" rel="noopener noreferrer" className="text-sky-400 hover:underline">https://t.me/XdyLn25</a></> 
        },
    ]);
    const [newMessage, setNewMessage] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(scrollToBottom, [messages]);

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (isOpen && event.key === 'Escape') {
                onClose();
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [isOpen, onClose]);

    const handleSendMessage = (e: React.FormEvent) => {
        e.preventDefault();
        if (newMessage.trim() === '') return;
        
        const userMessage = { id: Date.now(), from: 'user', text: newMessage };
        setMessages(prev => [...prev, userMessage]);
        setNewMessage('');
        
        // Simulate agent reply
        setTimeout(() => {
            const agentReply = { id: Date.now() + 1, from: 'agent', text: 'Thank you for your message. An agent will be with you shortly to assist with your query.' };
            setMessages(prev => [...prev, agentReply]);
        }, 1500);
    };

    if (!isOpen) return null;

    return (
        <div
            className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-end justify-end z-50 animate-fade-in-fast"
            role="dialog"
            aria-modal="true"
            onClick={onClose}
        >
            <div
                className="bg-white dark:bg-slate-800 rounded-t-xl sm:rounded-l-xl sm:rounded-tr-none shadow-2xl w-full h-[80%] sm:h-auto sm:max-h-[85vh] sm:w-[380px] m-0 sm:m-6 flex flex-col animate-slide-in"
                onClick={e => e.stopPropagation()}
            >
                {/* Header */}
                <header className="p-4 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center flex-shrink-0">
                    <div>
                        <h2 className="text-lg font-bold text-slate-900 dark:text-white">Live Support</h2>
                        <div className="flex items-center space-x-2">
                            <span className="relative flex h-2 w-2">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                            </span>
                            <p className="text-xs text-slate-500 dark:text-slate-400">Our team typically replies in a few minutes.</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700" aria-label="Close chat">
                        <CloseIcon className="w-5 h-5" />
                    </button>
                </header>

                {/* Messages */}
                <div className="flex-grow p-4 overflow-y-auto space-y-4">
                    {messages.map((msg) => (
                        <div key={msg.id} className={`flex items-end gap-2 ${msg.from === 'user' ? 'justify-end' : 'justify-start'}`}>
                            {msg.from === 'agent' && <img src="https://picsum.photos/seed/support/32" alt="Support Agent" className="w-8 h-8 rounded-full flex-shrink-0"/>}
                            <div className={`max-w-[80%] px-3 py-2 rounded-xl ${msg.from === 'user' ? 'bg-sky-500 text-white rounded-br-none' : 'bg-slate-100 dark:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-bl-none'}`}>
                                <p className="text-sm">{msg.text}</p>
                            </div>
                        </div>
                    ))}
                    <div ref={messagesEndRef} />
                </div>

                {/* Input */}
                <form onSubmit={handleSendMessage} className="p-4 border-t border-slate-200 dark:border-slate-700 flex items-center gap-2 flex-shrink-0">
                    <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Type your message..."
                        className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-full py-2 px-4 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                    />
                    <button type="submit" className="bg-sky-500 text-white rounded-full p-2.5 hover:bg-sky-600 transition-colors" aria-label="Send message">
                        <SendIcon className="w-5 h-5" />
                    </button>
                </form>
            </div>
            <style>{`
                @keyframes fade-in-fast { from { opacity: 0; } to { opacity: 1; } }
                .animate-fade-in-fast { animation: fade-in-fast 0.2s ease-out forwards; }

                @keyframes slide-in {
                    from { transform: translateY(100%) scale(0.95); }
                    to { transform: translateY(0) scale(1); }
                }
                @media (min-width: 640px) {
                    @keyframes slide-in {
                        from { transform: translateX(100%) scale(0.95); }
                        to { transform: translateX(0) scale(1); }
                    }
                }
                .animate-slide-in { animation: slide-in 0.3s cubic-bezier(0.25, 1, 0.5, 1) forwards; }
            `}</style>
        </div>
    );
};

export default LiveChatModal;